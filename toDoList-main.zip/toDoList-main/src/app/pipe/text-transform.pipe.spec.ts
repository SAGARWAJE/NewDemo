import { TextTransformPipe } from './text-transform.pipe';

describe('TextTransformPipe', () => {
  it('create an instance', () => {
    const pipe = new TextTransformPipe();
    expect(pipe).toBeTruthy();
  });
});
