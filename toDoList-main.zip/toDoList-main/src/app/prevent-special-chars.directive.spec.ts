import { PreventSpecialCharsDirective } from './prevent-special-chars.directive';

describe('PreventSpecialCharsDirective', () => {
  it('should create an instance', () => {
    const directive = new PreventSpecialCharsDirective();
    expect(directive).toBeTruthy();
  });
});
